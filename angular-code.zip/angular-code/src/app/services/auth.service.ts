import { Injectable } from '@angular/core';
import { HttpClient ,HttpHeaders ,HttpParams}   from '@angular/common/http'
import { Observable } from 'rxjs';
// import { tokenNotExpired } from 'angular2-jwt';





@Injectable({
  providedIn: 'root'
})
export default class AuthService {

  authToken: any;
  user: any;
  results: any;

  constructor(private httpclient: HttpClient) { }

  
  registerUser(user):Observable<any> {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.httpclient.post('http://localhost:5000/users/register', user, {headers: headers})
  
  
  }

  authenticateUser(user) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.httpclient.post('http://localhost:5000/users/Authenticate', user, {headers: headers})
   
  }


  storeUserData(token, user) {
    localStorage.setItem('id_token', token);
    localStorage.setItem('user', JSON.stringify(user));
    this.authToken = token;
    this.user = user;
  }

  logout() {
    this.authToken = null;
    this.user = null;
    localStorage.clear();
  }

  getProfile() {
    let headers = new HttpHeaders();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Content-Type', 'application/json');
    return this.httpclient.get('http://localhost:5000/users/profile', {headers: headers})
    
  }

  loadToken() {
    const token = localStorage.getItem('id_token');
    this.authToken = token;
  }

  loggedIn() {
   // return tokenNotExpired('id_token');
  }

}

